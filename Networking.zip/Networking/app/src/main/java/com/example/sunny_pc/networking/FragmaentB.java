package com.example.sunny_pc.networking;

import android.content.Context;
import android.media.Image;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;


public class FragmaentB extends Fragment{
    TextView textView;
    ImageView imageView;
    String imgname;
    String imgurl;

public FragmaentB(){
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        imgname=getArguments().getString("Img_Name");
        imgurl=getArguments().getString("Img_Url");

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_fragmaent_b, container,false);
        textView= (TextView) view.findViewById(R.id.text1);
        imageView= (ImageView) view.findViewById(R.id.img);

        textView.setText(imgname);
        Glide.with(getActivity()).load(imgurl).into(imageView);




        return view;
    }


}
