package com.example.sunny_pc.networking;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.LinearGradient;
import android.graphics.drawable.PictureDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.model.StreamEncoder;
import com.caverock.androidsvg.SVG;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class MovieArrayAdpter extends RecyclerView.Adapter<MovieArrayAdpter.ViewHolder> {

    private Context context;
    private List<MovieDetail> productList = new ArrayList<>();
    private moreDetailClickButton mdcb;


    public MovieArrayAdpter(List<MovieDetail> productList, moreDetailClickButton mdcb, Context context) {
        this.productList = productList;
        this.context = context;
        this.mdcb = mdcb;
    }


    public interface moreDetailClickButton {
        void ClickIt(MovieDetail movieDetail);
    }


    @NonNull
    @Override
    public MovieArrayAdpter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.moviedata, parent, false);

        ViewHolder viewHolder = new ViewHolder(itemView, mdcb);
        return viewHolder;

    }

    @Override
    public void onBindViewHolder(final MovieArrayAdpter.ViewHolder holder, final int position) {


        final MovieDetail product = productList.get(position);
        holder.name.setText(product.getImg_Name().toString());
        Glide.with(context).load(product.getImg_Url()).into(holder.imageView);

        holder.bind(product);
    }

    @Override
    public int getItemCount() {
        return productList.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView name, email, mobileno;
        ImageView imageView;
        moreDetailClickButton moreDetailClickButton;


        public ViewHolder(final View itemView, moreDetailClickButton moreDetailClickButton1) {
            super(itemView);
            name = (TextView) itemView.findViewById(R.id.textView);
            imageView = (ImageView) itemView.findViewById(R.id.imageView);
            moreDetailClickButton = moreDetailClickButton1;


        }

        public void bind(final MovieDetail movieDetail) {
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    mdcb.ClickIt(movieDetail);

                }
            });
        }
    }


}

