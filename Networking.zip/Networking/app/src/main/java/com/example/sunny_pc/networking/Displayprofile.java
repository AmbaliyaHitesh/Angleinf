package com.example.sunny_pc.networking;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;
import java.util.List;

public class Displayprofile extends AppCompatActivity {

    ImageView imageView;
    TextView textView;
    private List<MovieDetail> productList = new ArrayList<>();
    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_displayprofile);
        imageView=(ImageView)findViewById(R.id.image);
        textView=(TextView)findViewById(R.id.text);
           getinceming();

    }
    private void getinceming()
    {
        if (getIntent().hasExtra("Img_Name")&&getIntent().hasExtra("Img_Url")){

            String imgname=getIntent().getStringExtra("Img_Name");
            String imgurl=getIntent().getStringExtra("Img_Url");
            setimage(imgname,imgurl);
        }

    }
    private void setimage(String imgname,String imgurl)

    {


        Glide.with(getApplicationContext()).load(imgurl).into(imageView);
        textView.setText(imgname);

    }
}
