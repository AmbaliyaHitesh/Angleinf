package com.example.sunny_pc.networking;

public class MovieDetail  {


    public String getImg_Name() {
        return Img_Name;
    }

    public void setImg_Name(String img_Name) {
        Img_Name = img_Name;
    }

    public String getImg_Url() {
        return Img_Url;
    }

    public void setImg_Url(String img_Url) {
        Img_Url = img_Url;
    }

    private String Img_Name;
    private String Img_Url;

}
