package com.example.sunny_pc.networking;

import android.content.Context;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.caverock.androidsvg.SVG;
import com.caverock.androidsvg.SVGParseException;
import com.caverock.androidsvg.SVGParser;

import junit.framework.Assert;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.net.ssl.HttpsURLConnection;

public class MainActivity extends AppCompatActivity {
    URL url = null;
    Thread thread;
    RecyclerView recyclerView;
    RecyclerView.LayoutManager layoutManager;
    MovieArrayAdpter movieArrayAdpter;

    List<MovieDetail> productList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView = (RecyclerView) findViewById(R.id.recycler_view);



        new chackconnectionstutes().execute("http://www.newtechinfosol.co.in/UNIVERSAL/api/category?dbname=UNT17_SQL");

      /*  try {
            url=new URL("http://www.google.com/");

        } catch (MalformedURLException e) {
            e.printStackTrace();
        }



        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    HttpURLConnection urlConnection= (HttpURLConnection) url.openConnection();
                    Log.i("Response",String.valueOf(urlConnection.getResponseCode()));
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }).start();*/


    }


    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }

    public class chackconnectionstutes extends AsyncTask<String, Void, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(String... params) {
            try {
                url = new URL(params[0]);

            } catch (MalformedURLException e) {
                e.printStackTrace();
            }
            try {
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();

                InputStream inputStream = urlConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
                String s = bufferedReader.readLine();
                bufferedReader.close();
                return s;


            } catch (IOException e) {
                Log.e("Error", e.getMessage(), e);
            }
            return null;
        }

        @RequiresApi(api = Build.VERSION_CODES.KITKAT)
        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            JSONObject jsonObject = null;

            try {
                //  jsonObject = new JSONObject("ImageJson");


                JSONArray jsonArray = new JSONArray(s);

                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject object = jsonArray.getJSONObject(i);
                    //    MovieDetail movieDetail = new MovieDetail();
                    if (object.getString("ImageJson").equals("")) {
                        Toast.makeText(MainActivity.this, "no data found", Toast.LENGTH_SHORT).show();
                    } else {
                        String s2 = object.getString("ImageJson");
                        JSONArray jsonArray1 = new JSONArray(s2);
                        for (int j = 0; j < jsonArray1.length(); j++) {
                            JSONObject object1 = jsonArray1.getJSONObject(j);
                            MovieDetail movieDetail1 = new MovieDetail();
                            movieDetail1.setImg_Name(object1.getString("Img_Name"));
                            movieDetail1.setImg_Url(object1.getString("Img_Url"));
                            productList.add(movieDetail1);
                        }


                    }


                }
                layoutManager = new LinearLayoutManager(MainActivity.this);


                movieArrayAdpter = new MovieArrayAdpter(productList, new MovieArrayAdpter.moreDetailClickButton() {
                    @Override
                    public void ClickIt(MovieDetail movieDetail) {

                        FragmaentB fragmentB = new FragmaentB();
                        Bundle bundle = new Bundle();
                        bundle.putString("Img_Name", movieDetail.getImg_Name());
                        bundle.putString("Img_Url", movieDetail.getImg_Url());
                        fragmentB.setArguments(bundle);
                        FragmentManager manager = getSupportFragmentManager();
                        manager.popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);

                        FragmentTransaction transaction = manager.beginTransaction();
                        transaction.replace(R.id.relativ, fragmentB,null);
                        transaction.addToBackStack(null);// Toast.makeText(getApplicationContext(),"clik",Toast.LENGTH_SHORT).show();
                        transaction.commit();



                    }
                }, getApplicationContext());

                recyclerView.setLayoutManager(layoutManager);
                recyclerView.setAdapter(movieArrayAdpter);


            } catch (Exception e) {
                e.printStackTrace();
            }


        }

    }


}

